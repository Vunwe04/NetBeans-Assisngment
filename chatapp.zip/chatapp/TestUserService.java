/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author vunwe
 */

public class TestUserService {

    @Test
    public void testValidUsername() {
        assertTrue(UserService.checkUsername("usr_1"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(UserService.checkUsername("username!"));
        assertFalse(UserService.checkUsername("user_12345")); // too long
    }

    @Test
    public void testValidPassword() {
        assertTrue(UserService.checkPasswordComplexity("Pass@123"));
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(UserService.checkPasswordComplexity("pass123"));  
        assertFalse(UserService.checkPasswordComplexity("Password")); 
    }

    @Test
    public void testValidCellPhone() {
        assertTrue(UserService.checkCellPhoneNumber("+27612345678"));
    }

    @Test
    public void testInvalidCellPhone() {
        assertFalse(UserService.checkCellPhoneNumber("0612345678"));    
        assertFalse(UserService.checkCellPhoneNumber("+275"));          
    }

    @Test
    public void testSuccessfulRegistration() {
        User user = new User("usr_1", "Pass@123", "+27612345678", "Test", "User");
        String result = UserService.registerUser(user);
        assertEquals("User registered successfully!", result);
    }

    @Test
    public void testFailedRegistrationDueToUsername() {
        User user = new User("invalidUser", "Pass@123", "+27612345678", "Test", "User");
        String result = UserService.registerUser(user);
        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    public void testFailedRegistrationDueToPassword() {
        User user = new User("usr_1", "pass123", "+27612345678", "Test", "User");
        String result = UserService.registerUser(user);
        assertTrue(result.contains("Password is not correctly formatted"));
    }

    @Test
    public void testFailedRegistrationDueToPhone() {
        User user = new User("usr_1", "Pass@123", "0612345678", "Test", "User");
        String result = UserService.registerUser(user);
        assertTrue(result.contains("Cell phone number incorrectly formatted"));
    }
}
