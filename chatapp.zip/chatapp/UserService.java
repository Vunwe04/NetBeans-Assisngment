/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;
import java.util.regex.Pattern;
/**
 *
 * @author vunwe
 */

public class UserService {
    private static User registeredUser;

    public static boolean checkUsername(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
    }

    public static boolean checkCellPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^\\+27\\d{9}$");
    }

    public static String registerUser(User user) {
        if (!checkUsername(user.getUsername())) {
            return "Username is not correctly formatted, please ensure it contains an underscore and is no more than 5 characters.";
        }

        if (!checkPasswordComplexity(user.getPassword())) {
            return "Password is not correctly formatted. It must be at least 8 characters and contain a capital letter, number, and special character.";
        }

        if (!checkCellPhoneNumber(user.getPhoneNumber())) {
            return "Cell phone number incorrectly formatted or missing international code.";
        }

        registeredUser = user;
        return "User registered successfully!";
    }

    public static boolean loginUser(String username, String password) {
        return registeredUser != null &&
               registeredUser.getUsername().equals(username) &&
               registeredUser.getPassword().equals(password);
    }

    public static String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Welcome " + registeredUser.getFirstName() + " " + registeredUser.getLastName() + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}

