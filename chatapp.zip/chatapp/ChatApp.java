/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;

import java.util.Scanner;
/**
 *
 * @author vunwe
 */
public class ChatApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Registration
        System.out.println("=== REGISTER NEW USER ===");
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter a username: ");
        String username = scanner.nextLine();

        System.out.print("Enter a password: ");
        String password = scanner.nextLine();

        System.out.print("Enter phone number (e.g., +27612345678): ");
        String phone = scanner.nextLine();

        User newUser = new User(username, password, phone, firstName, lastName);
        String result = UserService.registerUser(newUser);
        System.out.println(result);

        if (!result.equals("User registered successfully!")) {
            System.out.println("Exiting due to registration failure.");
            return;
        }

        // Login
        System.out.println("\n=== LOGIN USER ===");
        System.out.print("Enter your username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = scanner.nextLine();

        boolean loggedIn = UserService.loginUser(loginUsername, loginPassword);
        System.out.println(UserService.returnLoginStatus(loggedIn));
    }
}
